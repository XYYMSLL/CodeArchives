//
//  ClosedDictionary.h
//  EECS 560 Closed Hashing
//
//  Created by heshuimu on 9/14/16.
//  Copyright © 2016 雪竜. All rights reserved.
//

#ifndef ClosedDictionary_h
#define ClosedDictionary_h

#define __RESET_COFLICT_RESOLVER__ _conflictResolver = -1;

#include <iostream>

class ClosedDictionary {
private:
	
	int _count;
	int _capacity;
	int* _data;
	bool* _deletedBucket;
	
	int _conflictResolver = -1;
	int hash(int x)
	{
		_conflictResolver++;
		
		if(_conflictResolver >= _capacity)
		{
			return -1;
		}
		
		return (x + _conflictResolver*_conflictResolver) % _capacity;
	}
	
public:
	
	ClosedDictionary(int capacity_a)
	{
		_count = 0;
		_capacity = capacity_a;
		_data = new int[capacity_a];
		_deletedBucket = new bool[capacity_a];
		for(int i = 0; i < _capacity; i++)
		{
			_data[i] = -1;
			_deletedBucket[i] = false;
		}
	}
	
	void Insert(int x)
	{
		if(Contains(x))
		{
			printf("Same key already existed: %i. ", x);
			return;
		}
		
		int h;
		while((h = hash(x)) != -1)
		{
			if(_data[h] == -1 && !_deletedBucket[h])
			{
				_data[h] = x;
				__RESET_COFLICT_RESOLVER__
				return;
			}
		}
		
		__RESET_COFLICT_RESOLVER__
		printf("Unable to resolve hash conflict for key: %i. ", x);
	}
	
	void Remove(int x)
	{
		int h;
		while((h = hash(x)) != -1)
		{
			if(_data[h] == x)
			{
				_data[h] = -1;
				_deletedBucket[h] = true;
				__RESET_COFLICT_RESOLVER__
				return;
			}
		}
		__RESET_COFLICT_RESOLVER__
	}
	
	void Print()
	{
		for(int i = 0; i < _capacity; i++)
		{
			printf("%i:\t%i\t(Flag = %s)\n", i, _data[i], _deletedBucket[i] ? "true" : "false");
		}
	}
	
	bool IsFull()
	{
		return _count >= _capacity;
	}
	
	bool Contains(int x)
	{
		int h;
		while((h = hash(x)) != -1)
		{
			if(_data[h] == x)
			{
				__RESET_COFLICT_RESOLVER__
				return true;
			}
		}
		__RESET_COFLICT_RESOLVER__
		return false;
	}
};

#endif /* ClosedDictionary_h */
