//
//  main.cpp
//  EECS 560 Closed Hashing
//
//  Created by heshuimu on 9/14/16.
//  Copyright © 2016 雪竜. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "ClosedDictionary.h"

ClosedDictionary* FileToLinkedList(const char* fileName)
{
	std::string line;
	std::ifstream data(fileName);
	if(data.is_open())
	{
		getline (data, line);
		std::stringstream ss(line);
		
		int t;
		ss >> t;
		
		ClosedDictionary* cd = new ClosedDictionary(t);
		
		while (ss >> t)
		{
			cd->Insert(t);
			
			if (ss.peek() == ' ')
				ss.ignore();
		}
		
		return cd;
	}
	else
	{
		return nullptr;
	}
}

int main(int argc, const char * argv[]) {
	
	bool run = true;
	ClosedDictionary* l = FileToLinkedList("test.txt");
	
	while (run)
	{
		std::cout<<"Please choose one of the following commands:\n1 - insert\n2 - delete\n3 - print\n4 - exit\n> ";
		
		int s;
		int i;
		
		std::cin >> i;
		
		switch (i) {
			case 1:
				std::cout<<"Choose a number to be inserted to the hash table:\n> ";
				std::cin >> s;
				l->Insert(s);
				break;
				
			case 2:
				std::cout<<"Choose a number to be removed from the list:\n> ";
				std::cin >> s;
				l->Remove(s);
				break;
				
			case 3:
				l->Print();
				break;
				
			default:
				run = false;
				break;
		}
	}
	
	delete l;
	
	return 0;
}
