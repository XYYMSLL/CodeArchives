//*****************************************************************************
//--AddSignedUnsignedTest.c
//
//              Author:          Gary J. Minden
//              Organization:   KU/EECS/EECS 645
//              Date:           2018-04-27 (B80427)
//              Version:                1.0
//              Description:    This program tests the Signed/Unsigned ADDs.
//              Notes:
//
//*****************************************************************************
//

int main() {
    
    int                     A = 32;
    int                     B = -32;
    unsigned int    C = 0xFFFFFFFF;
    unsigned int    D = 0x00005555;
    unsigned int    E;
    unsigned int    F;
    
    E = (int)A + (int)B;
    F = (unsigned int)C + (unsigned int)D;
    
    return( 1 );
    
}
