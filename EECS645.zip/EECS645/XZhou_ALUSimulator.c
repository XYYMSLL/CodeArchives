//*****************************************************************************
//--XZhou_ALUSimulator.c
//
//        Author:         Xianye Zhou
//        Organization:    KU/EECS/EECS 645
//        Date:            2018-05-02
//        Version:        1.0
//        Description:    This is the test standin for a simple ALU simulator
//        Notes:
//
//*****************************************************************************
//

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>

#include <stdio.h>

#include "RegisterFile_01.h"
#include "ALUSimulator.h"

extern void ALUSimulator( RegisterFile theRegisterFile,
                         uint32_t OpCode,
                         uint32_t Rs, uint32_t Rt, uint32_t Rd,
                         uint32_t ShiftAmt,
                         uint32_t FunctionCode,
                         uint32_t ImmediateValue,
                         uint32_t* Status ) {
    
    uint32_t S_Value, T_Value, D_Value;
    
    //report variable status
    printf( ">>ALU: Opcode: %02X; Rs: %02X; Rt: %02X; Rd: %02X;\n",
           OpCode,
           Rs,
           Rt,
           Rd );
    
    printf( ">>>>ALU: ShiftAmt: %02X; FunctionCode: %02X; ImmediateValue: %04X;\n",
           ShiftAmt,
           FunctionCode,
           ImmediateValue );
    
    //detect OpCode by if statement
    if(OpCode == 000000) {
        //OpCode is 000000
        
        if(FunctionCode == 000000) {
            //SLL
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = T_Value << ShiftAmt;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 000010) {
            //SRL
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = T_Value >> ShiftAmt;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 000011) {
            //SRA
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = T_Value >> ShiftAmt;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 000100) {
            //SLLV
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = T_Value << S_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 000110) {
            //SRLV
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = T_Value >> S_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 010000) {
            //MFHI
            //register 31 for HI
            RegisterFile_Cycle(theRegisterFile, 31, &S_Value, Rt, &T_Value, true, Rd, S_Value);
        }
        else if(FunctionCode == 010010) {
            //MFLO
            //register 30 for LO
            RegisterFile_Cycle(theRegisterFile, 30, &S_Value, Rt, &T_Value, true, Rd, S_Value);
        }
        else if(FunctionCode == 011000) {
            //MULT
            //store result to LO
            //register 30 for LO
            RegisterFile_Cycle(theRegisterFile, Rs, &S_Value, Rt, &T_Value, true, 30, ((int32_t)S_Value*(int32_t)T_Value));
        }
        else if(FunctionCode == 011001) {
            //MULTU
            //store result to LO
            RegisterFile_Cycle(theRegisterFile, Rs, &S_Value, Rt, &T_Value, true, 30, ((int32_t)S_Value*(int32_t)T_Value));
        }
        else if(FunctionCode == 011010) {
            //DIV
            //store s/t in LO, s%t in HI
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            RegisterFile_Write(theRegisterFile, true, 30, ((int32_t)S_Value/(int32_t)T_Value));
            RegisterFile_Write(theRegisterFile, true, 31, ((int32_t)S_Value%(int32_t)T_Value));
        }
        else if(FunctionCode == 011011) {
            //DIVU
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            RegisterFile_Write(theRegisterFile, true, 30, ((int32_t)S_Value/(int32_t)T_Value));
            RegisterFile_Write(theRegisterFile, true, 31, ((int32_t)S_Value%(int32_t)T_Value));
        }
        else if(FunctionCode == 100000) {
            //ADD
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = (int32_t)T_Value + (int32_t)S_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 100001) {
            //ADDU
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = (int32_t)T_Value + (int32_t)S_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 100010) {
            //SUB
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = (int32_t)S_Value - (int32_t)T_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 100011) {
            //SUBU
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = (int32_t)S_Value - (int32_t)T_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 100100) {
            //AND
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = (int32_t)S_Value & (int32_t)T_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 100101) {
            //OR
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = S_Value | T_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 100110) {
            //XOR
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            D_Value = S_Value ^ T_Value;
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 101010) {
            //SLT
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            if((int32_t)S_Value < (int32_t)T_Value) {
                D_Value = 1;
            }
            else
            {
                D_Value = 0;
            }
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
        else if(FunctionCode == 101011) {
            //SLTU
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            if(((int32_t)S_Value - (int32_t)T_Value) < 0) {
                D_Value = 1;
            }
            else
            {
                D_Value = 0;
            }
            RegisterFile_Write(theRegisterFile, true, Rd, D_Value);
        }
    } else {
        //OpCode is not 000000

        if(OpCode == 001000) {
            //ADDI
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            T_Value = (int32_t)S_Value+(int32_t)ImmediateValue;
            RegisterFile_Write(theRegisterFile, true, Rt, T_Value);
        }
        else if(OpCode == 001001) {
            //ADDIU
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            T_Value = (int32_t)S_Value+(int32_t)ImmediateValue;
            RegisterFile_Write(theRegisterFile, true, Rt, T_Value);
        }
        else if(OpCode == 001010) {
            //SLTI
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            if((int32_t)S_Value < (int32_t)ImmediateValue) {
                T_Value = 1;
            }
            else {
                T_Value = 0;
            }
            RegisterFile_Write(theRegisterFile, true, Rt, T_Value);
        }
        else if(OpCode == 001011) {
            //SLTIU
            RegisterFile_Read(theRegisterFile, Rs, &S_Value, Rt, &T_Value);
            if(((int32_t)S_Value - (int32_t)ImmediateValue) < 0) {
                T_Value = 1;
            }
            else {
                T_Value = 0;
            }
            RegisterFile_Write(theRegisterFile, true, Rt, T_Value);
        }
    }
}
