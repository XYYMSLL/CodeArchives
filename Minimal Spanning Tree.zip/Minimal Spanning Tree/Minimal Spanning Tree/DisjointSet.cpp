//
//  DisjointSet.cpp
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/27.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#include "DisjointSet.hpp"

DisjointSet::DisjointSet(int d) : dimension(d)
{
	auxiliaryArray = new DisjointSetParentPointerNode*[d];
	for(int i = 0; i < d; i++)
	{
		auxiliaryArray[i] = new DisjointSetParentPointerNode();
		auxiliaryArray[i]->parent = auxiliaryArray[i];
		auxiliaryArray[i]->rank = 0;
	}
}

DisjointSet::~DisjointSet()
{
	for(int i = 0; i < dimension; i++)
	{
		delete auxiliaryArray[i];
	}
	
	delete[] auxiliaryArray;
}

bool DisjointSet::IsInSameSet(int indexA, int indexB)
{
	return FindRoot(auxiliaryArray[indexA]) == FindRoot(auxiliaryArray[indexB]);
}

bool DisjointSet::Union(int indexA, int indexB)
{
	DisjointSetParentPointerNode* rootA = FindRoot(auxiliaryArray[indexA]);
	DisjointSetParentPointerNode* rootB = FindRoot(auxiliaryArray[indexB]);
	
	if(rootA == rootB)
		return false;
	
	if(rootA->rank < rootB ->rank)
		rootA->parent = rootB;
	else if(rootA->rank > rootB->rank)
		rootB->parent = rootA;
	else
	{
		rootB->parent = rootA;
		rootA->rank++;
	}
	
	return true;
}

DisjointSetParentPointerNode* DisjointSet::FindRoot(DisjointSetParentPointerNode* child)
{
	if(child->parent != child)
		child->parent = FindRoot(child->parent);
	
	return child->parent;
}
