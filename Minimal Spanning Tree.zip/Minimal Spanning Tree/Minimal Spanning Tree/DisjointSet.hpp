//
//  DisjointSet.hpp
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/27.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#ifndef DisjointSet_hpp
#define DisjointSet_hpp

#include "DisjointSetParentPointerNode.hpp"

class DisjointSet {
public:
	DisjointSet(int dimension);
	bool IsInSameSet(int indexA, int indexB);
	bool Union(int indexA, int indexB);
	~DisjointSet();
	
	
private:
	DisjointSetParentPointerNode** auxiliaryArray = nullptr;
	int dimension = 0;
	
	DisjointSetParentPointerNode* FindRoot(DisjointSetParentPointerNode* child);
	
};

#endif /* DisjointSet_hpp */
