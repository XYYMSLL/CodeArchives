//
//  DisjointSetParentPointerNode.hpp
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/27.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#ifndef DisjointSetParentPointerNode_hpp
#define DisjointSetParentPointerNode_hpp

class DisjointSetParentPointerNode {
	
public:
	DisjointSetParentPointerNode* parent = nullptr;
	int rank = 0;
	
};


#endif /* DisjointSetParentPointerNode_hpp */
