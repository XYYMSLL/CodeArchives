//
//  Path.cpp
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/27.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#include "Path.hpp"

Path::Path()
{
}

Path::Path(unsigned int a, unsigned int b, unsigned int d) : endpointA(a), endpointB(b), distance(d)
{
	if(endpointA > endpointB)
	{
		endpointB = a;
		endpointA = b;
	}
}

std::string Path::ToString() const
{
	std::stringstream ss;
	ss << "(" << endpointA << ", " << endpointB << ")";
	
	return ss.str();
}

bool Path::operator < (const Path &other)
{
	return distance < other.distance;
}

bool Path::operator > (const Path &other)
{
	return distance > other.distance;
}

bool Path::operator == (const Path &other)
{
	return distance == other.distance && endpointA == other.endpointA && endpointB == other.endpointB;
}

bool Path::operator <= (const Path &other)
{
	return distance <= other.distance;
}

bool Path::operator >= (const Path &other)
{
	return distance >= other.distance;
}
