//
//  Path.hpp
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/27.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#ifndef Path_hpp
#define Path_hpp

#include <string>
#include <sstream>

class Path {
	
public:
	unsigned int endpointA = -1, endpointB = -1;
	unsigned int distance = -1;
	
	Path();
	Path(unsigned int endpointA, unsigned int endpointB, unsigned int distance);
	std::string ToString() const;
	
	bool operator < (const Path &);
	bool operator > (const Path &);
	bool operator == (const Path &);
	bool operator <= (const Path &);
	bool operator >= (const Path &);
};

#endif /* Path_hpp */
