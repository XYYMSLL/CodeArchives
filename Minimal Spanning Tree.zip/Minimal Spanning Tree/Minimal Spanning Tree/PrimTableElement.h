//
//  PrimTableElement.h
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/27.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#ifndef PrimTableElement_h
#define PrimTableElement_h

struct PrimTableElement
{
	unsigned int m, O;
};

#endif /* PrimTableElement_h */
