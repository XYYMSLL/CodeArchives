//
//  SkewHeap.hpp
//  Leftish Heap
//
//  Created by heshuimu on 2016/11/7.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#ifndef LeftishHeap_hpp
#define LeftishHeap_hpp

#include <algorithm>
#include <iostream>
#include "TreeNode.h"

template <typename T> class SkewHeap {
public:
	~SkewHeap();
	void Insert(T x);
	T DeleteMin();
	bool IsEmpty();
	
private:
	
	TreeNode<T>* root = nullptr;
	unsigned int count = 0;
	
	TreeNode<T>* Merge(TreeNode<T>* treeA, TreeNode<T>* treeB);
	void Swap(TreeNode<T>*& treeA, TreeNode<T>*& treeB);
	void DeleteTree(TreeNode<T>* root);
};

template <typename T> bool SkewHeap<T>::IsEmpty()
{
	return count == 0;
}

template <typename T> SkewHeap<T>::~SkewHeap()
{
	DeleteTree(root);
}

template <typename T> void SkewHeap<T>::DeleteTree(TreeNode<T> *root)
{
	if(root == nullptr)
		return;
	
	DeleteTree(root->left);
	DeleteTree(root->right);
	
	delete root;
}

template <typename T> void SkewHeap<T>::Insert(T x)
{
	TreeNode<T>* newNode = new TreeNode<T>(x);
	root = Merge(root, newNode);
	count++;
}

template <typename T> T SkewHeap<T>::DeleteMin()
{
	if(IsEmpty())
		return T();
	
	TreeNode<T>* leftChild = root->left, *rightChild = root->right;
	T returnValue = root->val;
	delete root;
	count--;
	root = Merge(leftChild, rightChild);
	return returnValue;
}

template <typename T> void SkewHeap<T>::Swap(TreeNode<T>*& treeA, TreeNode<T>*& treeB)
{
	TreeNode<T>* temp = treeA;
	treeA = treeB;
	treeB = temp;
}

template <typename T> TreeNode<T>* SkewHeap<T>::Merge(TreeNode<T>* treeA, TreeNode<T>* treeB)
{
	if(treeA == nullptr && treeB == nullptr)
		return nullptr;
	
	if(treeA == nullptr && treeB != nullptr)
		return treeB;
	
	if(treeA != nullptr && treeB == nullptr)
		return treeA;
	
	if(treeA->val > treeB->val)
		Swap(treeA, treeB);
	
	TreeNode<T>* temp = treeA->right;
	treeA->right = treeA->left;
	treeA->left = Merge(temp, treeB);
	
	return treeA;
}

#endif /* LeftishHeap_hpp */
