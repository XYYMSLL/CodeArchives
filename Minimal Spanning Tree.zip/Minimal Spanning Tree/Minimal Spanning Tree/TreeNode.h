//
//  TreeNode.h
//  Leftish Heap
//
//  Created by heshuimu on 2016/11/7.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#ifndef TreeNode_h
#define TreeNode_h

template <typename T> class TreeNode
{
public:
	TreeNode() : val(T()){}
	TreeNode(T v) : val(v){}
	T val;
	TreeNode<T>* left = nullptr, *right = nullptr;
};


#endif /* TreeNode_h */
