//
//  main.cpp
//  Minimal Spanning Tree
//
//  Created by heshuimu on 2016/11/26.
//  Copyright © 2016年 雪竜. All rights reserved.
//

#include <iostream>
#include <fstream>
#include "DisjointSet.hpp"
#include "SkewHeap.hpp"
#include "Path.hpp"
#include "PrimTableElement.h"

void Kruskal(unsigned int** const matrix , unsigned int const size)
{
	DisjointSet cycleDetector(size);
	SkewHeap<Path> candidateQueue;
	Path* result = new Path[size - 1];
	unsigned int sizeOfResult = 0;
	
	for (unsigned int x = 0; x < size; x++)
	{
		for (unsigned int y = x + 1; y < size; y++)
		{
			candidateQueue.Insert(Path(x, y, matrix[x][y]));
		}
	}
	
	while(sizeOfResult < size - 1 && !candidateQueue.IsEmpty())
	{
		Path candidate = candidateQueue.DeleteMin();
		if(cycleDetector.Union(candidate.endpointA, candidate.endpointB))
		{
			result[sizeOfResult] = candidate;
			sizeOfResult++;
		}
	}
	
	if(sizeOfResult == size - 1)
	{
		std::cout << "Kruskal: ";
		for (unsigned int i = 0; i < sizeOfResult; i++)
		{
			std::cout << result[i].ToString();
			if (i != sizeOfResult - 1)
				std::cout << ", ";
		}
		std::cout << std::endl;
	}
	else
	{
		std::cout << "Kruskal: No feasible solution for this graph. ";
	}
	
	delete [] result;
}

void Prim(unsigned int** const matrix , unsigned int const size)
{
	if (size == 0) {
		return;
	}
	
	Path* result = new Path[size - 1];
	unsigned int sizeOfResult = 0;
	
	bool* markedVerticies = new bool[size];
	unsigned int sizeOfMarkedVerticies = 0;
	
	PrimTableElement* table = new PrimTableElement[size];
	
	for (unsigned int i = 0; i < size; i++)
	{
		table[i].m = matrix[0][i];
		table[i].O = 0;
		markedVerticies[i] = false;
	}
	
	markedVerticies[0] = true;
	sizeOfMarkedVerticies++;
	
	while(sizeOfMarkedVerticies < size)
	{
		unsigned int minDistance = -1, w = -1;
		
		for (unsigned int v = 0; v < size; v++)
		{
			if(markedVerticies[v])
				continue;
			
			if(table[v].m < minDistance)
			{
				minDistance = table[v].m;
				w = v;
			}
		}
		
		markedVerticies[w] = true;
		sizeOfMarkedVerticies++;
		
		result[sizeOfResult] = Path(w, table[w].O, matrix[w][table[w].O]);
		sizeOfResult++;
		
		table[w].m = -1;
		
		for (unsigned int v = 0; v < size; v++)
		{
			if(markedVerticies[v])
				continue;
			
			if(table[v].m > matrix[w][v])
			{
				table[v].m = matrix[w][v];
				table[v].O = w;
			}
		}
	}
	
	//Print result
	{
		std::cout << "Prim: ";
		for (unsigned int i = 0; i < sizeOfResult; i++)
		{
			std::cout << result[i].ToString();
			if (i != sizeOfResult - 1)
				std::cout << ", ";
		}
		std::cout << std::endl;
	}
	
	delete [] result;
	delete [] markedVerticies;
	delete [] table;
	
}



int main(int argc, const char * argv[])
{
	if(argc < 2)
		return 1;
	
	std::ifstream data(argv[1]);
	if(!data.is_open())
		return 2;
	
	int graphCounts;
	data >> graphCounts;
	
	for(int currentGraph = 0; currentGraph < graphCounts; currentGraph++)
	{
		unsigned int dimension;
		data >> dimension;
		
		unsigned int** graph = new unsigned int*[dimension];
		for (int i = 0; i < dimension; i++)
		{
			graph[i] = new unsigned int[dimension];
			for (unsigned int j = 0; j < dimension; j++)
			{
				data >> graph[i][j];
				if(graph[i][j] == 0)
					graph[i][j] = -1;
			}
		}
		
		std::cout << "Graph " << currentGraph << ":" << std::endl;
		
		Kruskal(graph, dimension);
		Prim(graph, dimension);
		
		for (unsigned int i = 0; i < dimension; i++)
		{
			delete [] graph[i];
		}
		
		delete [] graph;
		
	}
}
